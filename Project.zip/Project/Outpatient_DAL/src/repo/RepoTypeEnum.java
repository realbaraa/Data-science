
package repo;


public enum RepoTypeEnum{
    sqlRepo,MemoryRepo;
}
