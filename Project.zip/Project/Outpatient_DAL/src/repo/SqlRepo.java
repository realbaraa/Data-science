
package repo;

import java.util.List;
import model.Doctor;
import model.Patient;

public class SqlRepo implements IRepo {

    @Override
    public List<Patient> getPatients() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Doctor> getDoctors() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
